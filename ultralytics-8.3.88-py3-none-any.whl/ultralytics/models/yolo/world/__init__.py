# Ultralytics 🚀 AGPL-3.0 License - https://ultralytics.com/license

from .train import WorldTrainer

__all__ = ["WorldTrainer"]
